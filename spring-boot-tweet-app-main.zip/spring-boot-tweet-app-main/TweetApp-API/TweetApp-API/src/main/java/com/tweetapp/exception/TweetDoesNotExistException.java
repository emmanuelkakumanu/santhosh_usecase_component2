package com.tweetapp.exception;

public class TweetDoesNotExistException extends Exception {
	
	public TweetDoesNotExistException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}
}
